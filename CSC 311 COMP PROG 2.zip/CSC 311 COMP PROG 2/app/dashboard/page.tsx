"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Logo } from "@/components/logo"
import { Bell, Search } from "lucide-react"

export default function DashboardPage() {
  return (
    <div className="min-h-screen bg-background">
      <header className="flex items-center justify-between border-b p-4">
        <div className="flex items-center gap-4">
          <Logo />
          <div className="relative w-96">
            <Search className="absolute left-2 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
            <Input className="pl-8" placeholder="Search" />
          </div>
        </div>
        <div className="flex items-center gap-4">
          <span>Emmanuel Ngunnzi</span>
          <Button variant="ghost" size="icon">
            <Bell className="size-5" />
          </Button>
        </div>
      </header>
      <main className="container mx-auto p-6">
        <div className="mb-6 flex items-center justify-between">
          <h1 className="text-2xl font-semibold">Nairobi Air Quality Analysis and Visualization</h1>
          <Button>View Report</Button>
        </div>
        <div className="grid gap-6 lg:grid-cols-2">
          <Card className="col-span-2">
            <CardHeader>
              <CardTitle>Live Visualization</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="aspect-video overflow-hidden rounded-lg bg-[#1e4620]">
                <img
                  src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/CLIMATE%20ACTION%20SYSTEM%20(9)_page-0003.jpg-c88wEStRRSiuSfLQuRq8pnWXq7tzUW.jpeg"
                  alt="Map"
                  className="h-full w-full object-cover opacity-90"
                />
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle>Pollutant Percentages</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="relative aspect-square">
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="text-center">
                    <div className="text-4xl font-bold">90%</div>
                    <div className="text-sm text-muted-foreground">PM 2.5</div>
                  </div>
                </div>
                <svg className="h-full w-full" viewBox="0 0 100 100">
                  <circle
                    cx="50"
                    cy="50"
                    r="45"
                    fill="none"
                    stroke="#7ac943"
                    strokeWidth="10"
                    strokeDasharray="283"
                    strokeDashoffset="28"
                  />
                  <circle
                    cx="50"
                    cy="50"
                    r="35"
                    fill="none"
                    stroke="#ff4444"
                    strokeWidth="10"
                    strokeDasharray="220"
                    strokeDashoffset="77"
                  />
                  <circle
                    cx="50"
                    cy="50"
                    r="25"
                    fill="none"
                    stroke="#9333ea"
                    strokeWidth="10"
                    strokeDasharray="157"
                    strokeDashoffset="24"
                  />
                </svg>
              </div>
              <div className="mt-4 grid grid-cols-3 gap-4 text-center">
                <div>
                  <div className="text-2xl font-bold">85%</div>
                  <div className="text-sm text-muted-foreground">CO2</div>
                </div>
                <div>
                  <div className="text-2xl font-bold">65%</div>
                  <div className="text-sm text-muted-foreground">NO2</div>
                </div>
                <div>
                  <div className="text-2xl font-bold">90%</div>
                  <div className="text-sm text-muted-foreground">PM 2.5</div>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle>Most Polluted Areas</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {[
                  { name: "Gikomba", level: 110 },
                  { name: "Muthurwa", level: 97 },
                  { name: "Railways", level: 92 },
                  { name: "Machakos Country Bus", level: 88 },
                  { name: "Ngara", level: 82 },
                ].map((area) => (
                  <div key={area.name} className="flex items-center justify-between">
                    <span>{area.name}</span>
                    <span className="rounded-full bg-yellow-100 px-2 py-1 text-sm font-medium text-yellow-800">
                      {area.level}
                    </span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}

