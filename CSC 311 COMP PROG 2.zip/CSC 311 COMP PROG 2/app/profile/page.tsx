"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Logo } from "@/components/logo"
import { Bell } from "lucide-react"
import { Mail } from "lucide-react" // Import Mail icon

export default function ProfilePage() {
  return (
    <div className="min-h-screen bg-[#7ac943]/10">
      <header className="flex items-center justify-between border-b bg-white p-4">
        <div className="flex items-center gap-4">
          <Logo />
          <div>
            <h1 className="text-xl font-semibold">Welcome, Emmanuel</h1>
            <p className="text-sm text-muted-foreground">Tue, 07 June 2025</p>
          </div>
        </div>
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="icon">
            <Bell className="size-5" />
          </Button>
          <img
            src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/CLIMATE%20ACTION%20SYSTEM%20(9)_page-0005.jpg-k2ivZcbOBoKymWgEAMefqXt5rZDzG9.jpeg"
            alt="Profile"
            className="size-10 rounded-full object-cover"
          />
        </div>
      </header>
      <main className="container mx-auto max-w-4xl p-6">
        <Card>
          <CardContent className="p-6">
            <div className="mb-8 flex items-center gap-4">
              <img
                src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/CLIMATE%20ACTION%20SYSTEM%20(9)_page-0005.jpg-k2ivZcbOBoKymWgEAMefqXt5rZDzG9.jpeg"
                alt="Profile"
                className="size-16 rounded-full object-cover"
              />
              <div>
                <h2 className="text-xl font-semibold">Emmanuel Ngunnzi</h2>
                <p className="text-muted-foreground">ngunnzie@gmail.com</p>
              </div>
            </div>
            <div className="grid gap-6 md:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="fullName">Full Name</Label>
                <Input id="fullName" placeholder="Your Full Name" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="username">Username</Label>
                <Input id="username" placeholder="Your Preferred Username" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="gender">Gender</Label>
                <Select>
                  <SelectTrigger id="gender">
                    <SelectValue placeholder="Your Gender" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="male">Male</SelectItem>
                    <SelectItem value="female">Female</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="location">Location</Label>
                <Input id="location" placeholder="Your location of operation in Nairobi CBD" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="language">Language</Label>
                <Select>
                  <SelectTrigger id="language">
                    <SelectValue placeholder="Your Preferred Language" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="en">English</SelectItem>
                    <SelectItem value="fr">French</SelectItem>
                    <SelectItem value="es">Spanish</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="timezone">Time Zone</Label>
                <Select>
                  <SelectTrigger id="timezone">
                    <SelectValue placeholder="Your Time Zone" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="eat">EAT, UTC +3:00</SelectItem>
                    <SelectItem value="gmt">GMT, UTC +0:00</SelectItem>
                    <SelectItem value="est">EST, UTC -5:00</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="mt-8">
              <h3 className="mb-4 text-lg font-semibold">My email Address</h3>
              <div className="flex items-center gap-4 rounded-lg border p-4">
                <div className="size-10 rounded-full bg-blue-100 p-2">
                  <Mail className="size-6 text-blue-600" />
                </div>
                <div className="flex-1">
                  <p className="font-medium">ngunnzie@gmail.com</p>
                  <p className="text-sm text-muted-foreground">1 month ago</p>
                </div>
              </div>
              <Button variant="link" className="mt-2 text-[#7ac943]">
                + Add Email Address
              </Button>
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  )
}

